Asset info: 
- 1299 verts, 1548 tris in game engine
- 1 Mesh, 1 Material
- 2048 x 1024 textures
- FBX version: 2016/2017
- Object pivot is at approx mid of handle
- Real world scale: 43 cm

For Unity: 
- Use the textures provided in Unity_Textures.zip
- You may need to Extract Materials to access the texture slots
- Make sure Albedo color is pure white
- For the Metallic > Smoothness slider, recommended value is 0.8 

For Unreal Engine: 
- Use the textures provided in UE4_Textures.zip
- Contains channel packed ORM texture with Red = Occlusion, Green = Roughness, Blue = Metallic
- Turn off sRGB for Knife_OcclusionRoughnessMetallic.png 

Thank you for downloading this asset. I hope you found it useful! For support/collab/hire, contact me at vishalr.artstation.com

PS: I would appreciate a lot if you could take the time to hit Like (star) for this asset on sketchfab